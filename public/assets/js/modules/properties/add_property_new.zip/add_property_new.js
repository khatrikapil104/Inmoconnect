$(document).ready(function () {
    initialize();
    if (isEditPage == "Yes") {
        setTimeout(() => {
            $("#type_id").change();
            $("#category_id").change();
        }, 1000);
    }
});
$(document).on("click", ".addCreateNewPropertyBtn", function (e) {
    e.preventDefault();

    let sale_price = $("#sale_price").val();
    let short_price = $("#short_price").val();
    let long_price = $("#long_price").val();

    let price = null;

    if (sale_price !== null && sale_price !== "") {
        price = sale_price;
    } else if (short_price !== null && short_price !== "") {
        price = short_price;
    } else if (long_price !== null && long_price !== "") {
        price = long_price;
    }


    $btnName = $(this).text();
    $(this).prop("disabled", true);
    $(this).html(
        '<span class="spinner-grow spinner-grow-sm" role="status" aria-hidden="true"></span> ' +
        $btnName
    );
    const that = this;
    var formData = new FormData($("#addNewPropertyForm")[0]);

    formData.append("price", price);

    var files = $("#files").get(0).dropzone.files;
    for (var i = 0; i < files.length; i++) {
        formData.append("files[]", files[i]);
    }

    var cover_image = $("#cover_image").get(0).dropzone.files;
    for (var i = 0; i < cover_image.length; i++) {
        formData.append("cover_image", cover_image[i]);
    }

    let documentIds = [];
    let subFetureId = [];
    $(".removeDocumentBtn").each(function (index, elem) {
        documentIds.push($(elem).attr("data-id"));
    });
    $(".featureChekedId").each(function (index, featureId) {
        var feature_id = $(featureId).attr("data-id");
        if (!subFetureId[feature_id]) {
            subFetureId[feature_id] = [];
        }
        $(".subFetureCheckbox").each(function (index, elem) {
            if ($(elem).is(":checked") && feature_id != null) {
                if ($(elem).attr("feature_id") === feature_id) {
                    subFetureId[feature_id].push([$(elem).attr("data-id")]);
                }
            }
        });
    });

    $.each(subFetureId, function (feature_id, ids) {
        if (ids != null && feature_id != null) {
            formData.append("subFetureId[" + feature_id + "]", ids);
        }
    });
    formData.append("documentIds", documentIds.join(","));
    const attributes = {
        hasButton: true,
        btnSelector: ".addCreateNewPropertyBtn",
        btnText: $btnName,
        handleSuccess: function () {
            localStorage.setItem("flashMessage", datas["msg"]);
            window.location.href = datas["data"];
        },
        handleErrorMessages: function () {
            $.each(datas["errors"], function (index, html) {
                if (index == "files") {
                    $("#files")
                        .parent(".dynamic-dropzone-container")
                        .next()
                        .addClass("error");
                    $("#files")
                        .parent(".dynamic-dropzone-container")
                        .next()
                        .html(html);
                    $("#files")
                        .parent(".dynamic-dropzone-container")
                        .next()
                        .show();
                }
                if (index == "cover_image") {
                    $("#cover_image")
                        .parent(".dynamic-dropzone-container")
                        .next()
                        .addClass("error");
                    $("#cover_image")
                        .parent(".dynamic-dropzone-container")
                        .next()
                        .html(html);
                    $("#cover_image")
                        .parent(".dynamic-dropzone-container")
                        .next()
                        .show();
                }
            });
            var invalidFeedbackElements =
                document.getElementsByClassName("invalid-feedback");

            // Iterate through the elements
            for (var i = 0; i < invalidFeedbackElements.length; i++) {
                var element = invalidFeedbackElements[i];
                var computedStyle = window.getComputedStyle(element);
                if (computedStyle.display === "block") {
                    var scrollPosition =
                        element.getBoundingClientRect().top +
                        window.scrollY -
                        300;
                    window.scrollTo(0, scrollPosition);
                    break;
                }
            }
        },
    };
    const ajaxOptions = {
        url: routeUrl,
        method: "post",
        data: formData,
    };

    makeAjaxRequest(ajaxOptions, attributes);
});

// $(document).ready(function () {
//     $('#owner_id').change(function () {
//         var selectedAgentId = $(this).val();

//         var agentDetailsUrl = geAgentDetailsUrl.replace(':id',selectedAgentId);
//         $.ajax({
//             url: agentDetailsUrl,
//             method: 'GET',
//             success: function (response) {
//                 // Update the details based on the response
//                 $('#vendor_name').val(response.name);
//                 $('#vendor_mobile').val(response.phone);
//                 $('#vendor_email').val(response.email);
//             },
//             error: function (error) {
//                 console.log(error);
//             }
//         });
//     });
// });

var autocomplete;

function initialize() {
    var options = {
        // componentRestrictions: {
        //     country: "fr"
        // }
    };

    var acInput = document.getElementById("address");
    // for (var i = 0; i < acInputs.length; i++) {
    var autocomplete = new google.maps.places.Autocomplete(acInput, options);
    autocomplete.inputId = acInput.id;
    google.maps.event.addListener(autocomplete, "place_changed", function () {
        var place = this.getPlace();
        var lat = place.geometry.location.lat();
        var lng = place.geometry.location.lng();
        $("#latitude_v").val(lat);
        $("#longitude_v").val(lng);
        var doorFlatNo = "";
        var streetName = "";
        // console.log(place);
        // Extract door/flat no. and street from address components
        for (var i = 0; i < place.address_components.length; i++) {
            var component = place.address_components[i];
            if (component.types.includes("subpremise")) {
                doorFlatNo = component.short_name;
                break;
            } else if (component.types.includes("premise")) {
                doorFlatNo = component.short_name;
                break;
            } else if (component.types.includes("street_number")) {
                doorFlatNo = component.short_name;
            }
        }
        // Update visible text fields
        $("#street_number_v").val(doorFlatNo);
        // $("#cou").val(doorFlatNo);

        // Extract street name
        for (var i = 0; i < place.address_components.length; i++) {
            var component = place.address_components[i];
            if (component.types.includes("route")) {
                streetName = component.short_name;
                break;
            }
        }

        // Update visible text field for street name
        $("#street_name_v").val(streetName);

        // Extract country, state, city, and zipcode from address components
        var country = "";
        var state = "";
        var city = "";
        var zipcode = "";

        for (var i = 0; i < place.address_components.length; i++) {
            var component = place.address_components[i];

            if (component.types.includes("country")) {

                country = component.long_name;
                console.log(country);
            } else if (
                component.types.includes("administrative_area_level_1")
            ) {
                state = component.long_name;
            } else if (component.types.includes("locality")) {
                city = component.long_name;
            } else if (component.types.includes("postal_code")) {
                zipcode = component.short_name;
            }
        }

        // Update hidden fields
        $("#country_v").val(country);
        $("#country").val(country);
        $("#state_provenience").val(state);
        $("#city").val(city);

        // Update visible text field for zipcode
        $("#zipcode_v").val(zipcode);

        initMapOnChange();
    });
    // }
}

$(document).on("click", ".locateAddressBtn", function () {
    initMapOnChange();
});

function initMap() {
    let latVal = $("#latitude_v").val();
    let lngVal = $("#longitude_v").val();

    if (latVal && lngVal) {
        // Initialize the map
        var map = new google.maps.Map(document.getElementById("propertyMap"), {
            center: { lat: parseFloat(latVal), lng: parseFloat(lngVal) },
            zoom: 15,
        });

        // Add a marker
        var marker = new google.maps.Marker({
            position: { lat: parseFloat(latVal), lng: parseFloat(lngVal) },
            map: map,
        });
    } else {
        // Initialize the map
        var map = new google.maps.Map(document.getElementById("propertyMap"), {
            center: { lat: 40.83984419999999, lng: -73.079011 },
            zoom: 10,
        });
    }
}

function initMapOnChange() {
    $(".invalid-feedback").html("");
    $(".invalid-feedback").removeClass("error");
    $(".is-invalid").removeClass("is-invalid");
    let latVal = $("#latitude_v").val();
    let lngVal = $("#longitude_v").val();
    if (latVal && lngVal) {
        // Initialize the map
        var map = new google.maps.Map(document.getElementById("propertyMap"), {
            center: { lat: parseFloat(latVal), lng: parseFloat(lngVal) },
            zoom: 15,
        });

        // Add a marker
        var marker = new google.maps.Marker({
            position: { lat: parseFloat(latVal), lng: parseFloat(lngVal) },
            map: map,
            draggable: true,
        });

        // Add event listener for marker dragend event
        google.maps.event.addListener(marker, "dragend", function () {
            // Get the updated position of the marker
            const markerPosition = marker.getPosition();
            // Use Geocoder to get address details based on marker position
            const geocoder = new google.maps.Geocoder();
            geocoder.geocode({ location: markerPosition },
                function (results, status) {
                    console.log(status);
                    if (status === "OK") {
                        if (results[0]) {
                            // Display the formatted address in the console
                            console.log(
                                "Address:",
                                results[0].formatted_address
                            );
                        } else {
                            console.error("No results found");
                        }
                    } else {
                        console.error("Geocoder failed due to: " + status);
                    }
                }
            );
        });
        // }P
    } else {
        $("#address").addClass("is-invalid");
        $("#address").next().addClass("error");
        $("#address").next().html(invalidAddressText);
        $("#address").show();
    }
}

$(document).ready(function () {
    $("#type_id").change(function () {
        var typeId = $(this).val();

        if (typeId === "") {
            $("#subtype").empty().prop("disabled", true);
            return; // Exit early if no type is selected
        }
        var subtypeUrl = subtypeSelectedTypeId.replace(":typeId", typeId);
        var selectedSubtypeId = subTypeId ? subTypeId : $("#subtype").val();

        $.ajax({
            url: subtypeUrl,
            type: "GET",
            success: function (response) {
                var subtypes = response;
                $("#subtype").empty().prop("disabled", false);
                $("#subtype2").empty().prop("disabled", false);

                $.each(subtypes, function (index, subtype) {
                    $("#subtype").append(
                        '<option value="' +
                        subtype.id +
                        '">' +
                        subtype.name +
                        "</option>"
                    );
                    $("#subtype2").append(
                        '<option value="' +
                        subtype.id +
                        '">' +
                        subtype.name +
                        "</option>"
                    );
                });
                $("#subtype").val(selectedSubtypeId);
            },
            error: function (xhr, status, error) {
                console.error("Failed to fetch subtypes");
            },
        });
    });
});

// <!-- select type plot that time show and hide field  -->

$(document).ready(function () {
    $("#type_id").change(function () {
        var selectedType = $(this).find("option:selected").text();
        // console.log(selectedType)
        if (selectedType === "Plot") {
            $(
                "#bedrooms, #bathrooms, #floors, #total_size, #storeys, #no_of_properties_builtin, #terrace, #levels, #garden_plot, #properties_int_floor_space, #agency_ref"
            ).hide();
            $("#plot_size").show();
        } else {
            $(
                "#bedrooms, #bathrooms,#floors,#total_size,#storeys,#no_of_properties_builtin,#terrace,#levels,#garden_plot,#properties_int_floor_space, #agency_ref"
            ).show();
            $("#plot_size").hide();
        }
    });
});

// <!-- select type Commercial that time show and hide field  -->

$(document).ready(function () {
    $("#type_id").change(function () {
        var selectedType = $(this).find("option:selected").text();
        if (selectedType === "Commercial") {
            $("#commercial_checkbox_container").removeClass("d-none");
            $("#subtype2Container").show();
        } else {
            $("#commercial_checkbox_container").addClass("d-none");
            $("#subtype2Container").hide();
        }
    });
});

//category select short term and long term option that time show and hide field

$(document).ready(function () {
    $("#category_id").change(function () {
        var selectedCategory = $(this).find("option:selected").text();

        if (selectedCategory === "Short Term Rental") {
            $("#short-term-ref-field").show();
            $("#long-term-ref-field").hide();
            $("#rental-license-ref-field").show();
        } else if (selectedCategory === "Long Term Rental") {
            $("#short-term-ref-field").hide();
            $("#long-term-ref-field").show();
            $("#rental-license-ref-field").show();
        } else {
            $("#short-term-ref-field").hide();
            $("#long-term-ref-field").hide();
            $("#rental-license-ref-field").hide();
        }
    });
});
//select listed by dropdown agent based on filled this filed
$(document).ready(function () {
    $("#owner_id").change(function () {
        var selectedAgentId = $(this).val();

        var agentDetailsUrl = geAgentDetailsUrl.replace(":id", selectedAgentId);
        $.ajax({
            url: agentDetailsUrl,
            method: "GET",
            success: function (response) {
                // Update the details based on the response
                $("#contact_name").val(response.name);
                $("#contact_mobile").val(response.phone);
                $("#contact_email").val(response.email);
                $("#contact_city").val(response.city);
                $("#contact_state_province").val(response.state);
                $("#contact_country").val(response.country);
                $("#contact_zipcode").val(response.zipcode);
                $("#contact_street_address").val(response.address);
                $("#company_name").val(response.company_name);
            },
            error: function (error) {
                console.log(error);
            },
        });
    });
});

//Remove File in edit property page
$(document).ready(function () {
    $(".removeFileBtn").on("click", function () {
        var parentElement = $(this).closest(".text-14");
        parentElement.empty();
    });
});

function handleDocumentsSelect(event) {
    const fileList = event.target.files;

    const formData = new FormData();
    // Append each file to FormData
    for (const file of fileList) {
        formData.append("files[]", file);
    }

    let documentIds = [];
    $(".removeDocumentBtn").each(function (index, elem) {
        documentIds.push($(elem).attr("data-id"));
    });
    formData.append("documentIds", documentIds.join(","));

    $(".propertyDocumentsDiv").addClass("loader");
    const attributes = {
        hasButton: false,
        handleSuccess: function () {
            $(".propertyDocumentsData").html(datas["data"]);
            $(".propertyDocumentsDiv").removeClass("loader");
        },
        handleError: function () {
            $(".propertyDocumentsDiv").removeClass("loader");
        },
        handleErrorMessages: function () {
            $.each(datas["errors"], function (index, html) {
                $(".propertyDocumentsDiv").removeClass("loader");
                $(".propertyDocumentsData").next().addClass("error");
                $(".propertyDocumentsData").next().html(html);
                $(".propertyDocumentsData").next().show();
            });
        },
    };
    const ajaxOptions = {
        url: addDocumentUrl,
        method: "post",
        data: formData,
    };
    makeAjaxRequest(ajaxOptions, attributes);
}

$(document).on("click", ".removeDocumentBtn", function () {
    $(".propertyDocumentsDiv").addClass("loader");
    const attributes = {
        hasButton: false,
        handleSuccess: function () {
            $(".propertyDocumentsData").html(datas["data"]);
            $(".propertyDocumentsDiv").removeClass("loader");
        },
        handleError: function () {
            $(".propertyDocumentsDiv").removeClass("loader");
        },
        handleErrorMessages: function () {
            $(".propertyDocumentsDiv").removeClass("loader");
        },
    };
    let documentId = $(this).attr("data-id");

    let documentIds = [];
    $(".removeDocumentBtn").each(function (index, elem) {
        documentIds.push($(elem).attr("data-id"));
    });

    let url =
        removeDocumentUrl.replace(":id", documentId) +
        "?documentIds=" +
        documentIds.join(",");
    const ajaxOptions = {
        url: url,
        method: "get",
    };
    makeAjaxRequest(ajaxOptions, attributes);
});

// <!--select status completion that time show and hide field  -->

$(document).ready(function () {
    // Function to handle showing or hiding fields based on the status completion
    function handleStatusCompletion() {
        var selectedStatus = $("#completion_status_one").find("option:selected").val();
        if (selectedStatus === "Completed") {
            $("#year_completed_container").show();
            $("#month_year_container").hide();
        } else {
            $("#year_completed_container").hide();
            $("#month_year_container").show();
        }
    }

    handleStatusCompletion();

    $("#completion_status_one").change(function () {
        handleStatusCompletion();
    });
});

// Property Pricing according to types

$(document).ready(function () {
    // Function to handle showing or hiding fields based on the selected option
    function handleOptionSelection() {
        var selectedOption = $("#pro_listed_as").find("option:selected").val();
        if (selectedOption === "for_sale") {
            // Show sale-related fields
            $("#sale_price_container").show();
            $("#rental_conatiner").hide();
            $("#short_term_container").hide();
            $("#long_term_container").hide();
            $("#percentage_container").show();
            $("#commission_container").show();
            $("#net_price_container").show();
            $("#listing_container").show();
            $("#selling_container").show();
            $("#value_deed_container").show();
            $("#minimun_container").show();
            $("#fees_tax_container").show();
            $("#commission_note_container").show();
            $("#allow_required_container").hide();
            $("#rent_certificate_container").hide();

        } else if (selectedOption === "for_rent") {
            // rent-related fields should be shown
            $("#rental_conatiner").show();
            $("#sale_price_container").hide();
            $("#short_term_container").show();
            $("#percentage_container").show();
            $("#commission_container").show();
            $("#net_price_container").hide();
            $("#listing_container").show();
            $("#selling_container").show();
            $("#value_deed_container").hide();
            $("#minimun_container").hide();
            $("#fees_tax_container").hide();
            $("#commission_note_container").show();
            $("#allow_required_container").show();
            $("#rent_certificate_container").show();

        }
    }

    handleOptionSelection();

    $("#pro_listed_as").change(function () {
        handleOptionSelection();
    });
});


// <!--Rent type hide and show -->

$(document).ready(function () {

    function handleStatusCompletion() {
        var selectedStatus = $("#rent_type").val();

        if (selectedStatus === "short_term") {
            $("#sale_price").val("");
            $("#short_term_container").show();
            $("#long_term_container").hide();
        } else if (selectedStatus === "long_term") {
            $("#long_term_container").show();
            $("#short_term_container").hide();
        } else {
            $("#long_term_container").hide();
            $("#short_term_container").hide();
        }
    }

    handleStatusCompletion();

    $("#rent_type").change(function () {
        handleStatusCompletion();
    });
});

// <!--Rental type hide and show  --> 
$(document).ready(function () {
    // Initially hide the rental container
    $('#rental_conatiner').hide();

    // Add an event listener for changes to the "Property Listed As" dropdown
    $('#pro_listed_as').on('change', function () {
        var selectedValue = $(this).val();

        if (selectedValue === 'for_rent') {
            // Show rental container if "For Rent" is selected
            $('#rental_conatiner').show();
        } else {
            // Hide rental container for any other selection
            $('#rental_conatiner').hide();
        }
    });
});



$(document).on("click", ".addSubFeturesBtn", function () {
    const formData = new FormData($("#addNewPropertyForm")[0]);
    var featureId = $(this).data("id");
    $(".subFetureCheckbox").each(function (index, elem) {
        if ($(elem).is(":checked")) {
            formData.append("subFetureId[]", $(elem).data("id"));
        }
    });
    $(".checkbox_modal").modal("hide");
});